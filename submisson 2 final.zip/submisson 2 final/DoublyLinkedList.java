public class CircularDoublyLinkedList {

    class Node {
        int data;
        Node prev;
        Node next;

        Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    Node head;
    Node tail;

    public void insertAtBeginning(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = tail = newNode;
            newNode.next = newNode;
            newNode.prev = newNode;
        } else {
            newNode.next = head;
            newNode.prev = tail;
            head.prev = newNode;
            tail.next = newNode;
            head = newNode;
        }
        System.out.println(data + " inserted");
    }

    public void insertAtEnd(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = tail = newNode;
            newNode.next = newNode;
            newNode.prev = newNode;
        } else {
            newNode.next = head;
            newNode.prev = tail;
            tail.next = newNode;
            head.prev = newNode;
            tail = newNode;
        }
        System.out.println(data + " inserted");
    }

    public void delete(int data) {
        if (head == null) {
            System.out.println("Value not found");
            return;
        }

        Node current = head;

        do {
            if (current.data == data) {
                if (current == head && current == tail) {
                    head = tail = null;
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                    if (current == head) head = current.next;
                    if (current == tail) tail = current.prev;
                }
                System.out.println(data + " deleted");
                return;
            }
            current = current.next;
        } while (current != head);

        System.out.println("Value not found");
    }

    public void displayForward() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        System.out.print("Forward: ");
        Node current = head;
        do {
            System.out.print(current.data + " <-> ");
            current = current.next;
        } while (current != head);
        System.out.println("(back to head)");
    }

    public void displayBackward() {
        if (tail == null) {
            System.out.println("List is empty");
            return;
        }
        System.out.print("Backward: ");
        Node current = tail;
        do {
            System.out.print(current.data + " <-> ");
            current = current.prev;
        } while (current != tail);
        System.out.println("(back to tail)");
    }

    public static void main(String[] args) {
        CircularDoublyLinkedList list = new CircularDoublyLinkedList();

        list.insertAtBeginning(20);
        list.insertAtBeginning(10);
        list.insertAtEnd(30);
        list.insertAtEnd(40);

        list.displayForward();
        list.displayBackward();

        list.delete(20);

        list.displayForward();
        list.displayBackward();
    }
}