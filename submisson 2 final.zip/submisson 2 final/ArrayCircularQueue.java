public class ArrayCircularDeque {

    private int[] arr;
    private int front;
    private int rear;
    private int size;
    private int capacity;

    public ArrayCircularDeque(int capacity) {
        this.capacity = capacity;
        arr = new int[capacity];
        front = 0;
        rear = 0;
        size = 0;
    }

    public void insertFront(int value) {
        if (size == capacity) {
            System.out.println("Deque is full");
            return;
        }
        front = (front - 1 + capacity) % capacity;
        arr[front] = value;
        size++;
        System.out.println(value + " inserted at front");
    }

    public void insertRear(int value) {
        if (size == capacity) {
            System.out.println("Deque is full");
            return;
        }
        rear = (rear + 1) % capacity;
        arr[rear] = value;
        size++;
        System.out.println(value + " inserted at rear");
    }

    public int deleteFront() {
        if (size == 0) {
            System.out.println("Deque is empty");
            return -1;
        }
        int removed = arr[front];
        front = (front + 1) % capacity;
        size--;
        return removed;
    }

    public int deleteRear() {
        if (size == 0) {
            System.out.println("Deque is empty");
            return -1;
        }
        int removed = arr[rear];
        rear = (rear - 1 + capacity) % capacity;
        size--;
        return removed;
    }

    public void display() {
        if (size == 0) {
            System.out.println("Deque is empty");
            return;
        }
        System.out.print("Deque: ");
        for (int i = 0; i < size; i++) {
            int index = (front + i) % capacity;
            System.out.print(arr[index] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        ArrayCircularDeque d = new ArrayCircularDeque(5);

        d.insertRear(10);
        d.insertRear(20);
        d.insertFront(5);
        d.insertRear(30);
        d.display();

        System.out.println("Deleted front: " + d.deleteFront());
        System.out.println("Deleted rear: " + d.deleteRear());

        d.insertFront(1);
        d.insertRear(40);
        d.display();
    }
}